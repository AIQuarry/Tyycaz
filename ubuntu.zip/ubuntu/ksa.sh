cd /d "%~dp0"
./xmrig. -o randomx.rplant.xyz:17123 -a rx/0 -u TuskeMe2WPeisnKTkzCKsFCPLvXQK2vu2b7197qKAVxTBCihAALZufseGpLf1ytdfxHfCDu3nenQM6LUZECgNChW3g9W441ywSX31 --tls 
pause